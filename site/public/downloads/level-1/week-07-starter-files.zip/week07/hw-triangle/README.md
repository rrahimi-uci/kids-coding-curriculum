# Homework 7 - Triangle Time

**Goal:** make the turtle draw a triangle with three equal sides.

1. Open `starter.py` in Thonny.
2. The turtle already draws ONE side. Add the code for the other two sides.
3. A triangle turns **120 degrees** at each corner (3 x 120 = 360, one full turn).
4. Press **Run** (F5) and watch.

**Done looks like:** a closed triangle - the turtle ends where it started.

**Challenge:** under the triangle, draw a square in a different color from
the palette (move with `t.penup()`, `t.forward(150)`, `t.pendown()` first).

