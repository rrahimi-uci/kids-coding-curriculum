# Exercise 2.2 - Bubble Art

**Goal:** finish a `Bubble` class and use it to paint a picture full of
bubbles. Each bubble is an object that remembers its own `x`, `y`, `size`
and `color`.

1. Open `starter.py` in Thonny.
2. Finish the `TODO`s: `__init__`, `grow`, `move`, the big dot in `draw`,
   and `make_bubbles`.
3. Press **Run**. A black window fills with 40 colorful bubbles, each with a
   little white shine.

**Extra:** add a method `pop(self, t)` that draws a ring of small dots
around the bubble, or make bubbles near the top of the screen bigger.

